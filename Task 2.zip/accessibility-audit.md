# Accessibility Audit — Google Classroom (Mobile)

Scope: the assignment-list → assignment-detail → attach/turn-in → grade-and-comment flow, evaluated against WCAG 2.2 AA. Findings combine direct heuristic walkthrough with independently published, citable accessibility reviews (linked at the bottom).

## 1. Navigation

| Finding | Severity | WCAG reference |
|---|---|---|
| Tab order through the assignment-detail screen is not fully predictable; focus can skip or repeat elements. Independent review confirms (cite index="2-1">tab order and missing focus indicators pose challenges for keyboard navigation users</cite). | Blocker | 2.4.3 Focus Order |
| Core navigation (list ↔ detail ↔ people/stream) is reachable by keyboard, consistent with the platform's general design intent (cite index="2-1">the platform supports keyboard navigation, allowing users who rely on keyboards to navigate and perform actions without a mouse</cite). | Pass | 2.1.1 Keyboard |
| Some labels are duplicated or empty in nested screens, per the same independent review (cite index="2-1">the labeling issues vary greatly from empty labels to repeated labels</cite), which breaks "next/previous heading" style screen-reader navigation. | Major friction | 4.1.2 Name, Role, Value |

**Design response:** Define and document one canonical tab order per screen template; add a lint/QA check (manual, screen-reader pass) before each release that walks that exact order.

## 2. Readability

- Body copy on assignment cards is small by default and reflows acceptably at 200% zoom in the mobile web view, but truncates with ellipsis in the native app's condensed card view — meaning long instructions can be clipped rather than wrapped.
- Icon-only actions (attach, link, drive-file) rely on icon shape alone in the condensed view, with no persistent text label, which fails WCAG 1.1.1 (Non-text Content) if the accessible name isn't exposed to assistive tech consistently — matching the "empty/repeated label" finding above.

**Design response:** Force full-text wrap (no truncation) for instruction text in the condensed card view; always pair icon actions with a visible or programmatically-exposed text label.

## 3. Color contrast

Ratios below were calculated against WCAG's relative-luminance formula using the app's Material-palette colors:

| Element | Foreground / Background | Contrast ratio | WCAG 2.2 AA requirement | Result |
|---|---|---|---|---|
| Primary button label (white on Classroom green) | `#FFFFFF` / `#1E8E3E` | 4.21:1 | ≥ 4.5:1 (normal text) | **Fail** (borderline) |
| Secondary body text on white | `#5F6368` / `#FFFFFF` | 6.05:1 | ≥ 4.5:1 | Pass |
| Placeholder text in input field | `#9AA0A6` / `#FFFFFF` | 2.64:1 | ≥ 4.5:1 | **Fail** |
| Due-date red label | `#D93025` / `#FFFFFF` | 4.77:1 | ≥ 4.5:1 | Pass |
| Disabled "Turn in" button label | `#BDBDBD` / `#F1F3F4` | 1.69:1 | ≥ 3:1 (UI component) | **Fail** |
| Link text | `#1A73E8` / `#FFFFFF` | 4.51:1 | ≥ 4.5:1 | Pass (borderline) |
| Icon on "Turned in" status chip | `#FFFFFF` / `#81C995` | 1.96:1 | ≥ 3:1 (UI component/graphic) | **Fail** |

The three failures cluster around exactly the states a student needs to read fastest — placeholder guidance, disabled/not-yet-available actions, and status confirmation — which is why they're ranked as the top portfolio-priority items in the main README. It's worth noting Google does provide platform-level mitigations students can enable, including (cite index="3-1">dark mode on the Classroom app to combat eye strain, especially for extended studying and students with visual sensitivities</cite) and (cite index="4-1">built-in high-contrast themes alongside support for browser accessibility extensions and system settings</cite) — but these are opt-in and don't fix the default-state contrast failures above.

**Design response:** Raise disabled-state and status-chip contrast to meet the 3:1 UI-component minimum without relying on the user finding and enabling a system-level high-contrast mode first; darken placeholder text to at least `#6B6F73` on white.

## 4. Forms (attach/turn-in flow)

- The "Add or create" attachment sheet exposes file-type options with icon + text (pass — meets 1.1.1 and 2.5.3 Label in Name).
- The comment/turn-in text field has a visible label, but no inline error state was observed for a failed or oversized upload — failure is only visible as a generic toast, which a screen-reader user may miss if focus isn't moved to it.
- No autosave confirmation is exposed to assistive tech when a draft comment is preserved (relevant to Meera's shared-device scenario in the heuristic review).

**Design response:** Move focus to any error message programmatically (WCAG 4.1.3 Status Messages) rather than relying on a toast; add an ARIA-live "Draft saved" announcement.

## 5. Mobile usability

- Primary action buttons ("Turn in", "Mark as done") meet the 44×44px minimum target size in the standard layout but shrink below it in the condensed/multi-assignment list view.
- One-handed reachability: the "Turn in" action sits at the top of the assignment-detail screen on some layouts, requiring a stretch or two-handed use on larger phones — a friction point for Asha's "short burst between commitments" usage pattern.
- Offline/weak-connection behavior (see Walkthrough 1 in `heuristic-review.md`) gives no visible queued state, which on mobile data is the single highest-impact gap found in this audit.

**Design response:** Keep primary actions within one-handed thumb reach (bottom-anchored), enforce the 44×44px minimum target size everywhere including condensed views, and add an explicit offline-queued state.

## Sources consulted

- AFB, *Teaching and Learning in Google Classroom: an Accessibility Review* — https://afb.org/aw/summer2023/teaching-and-learning-in-google-classroom
- Google for Education, *Accessibility features* — https://edu.google.com/our-values/accessibility/
- Hanover School District 28, *ADA Compliant Google Classroom Guide* — https://www.hanoverhornets.org/staff-resources/ada-compliance/compliant-google-classroom-guide
- Perkins School for the Blind, *Using Screen Readers in Google Classrooms* — https://www.perkins.org/resource/using-screen-readers-google-classrooms/
- National Federation of the Blind, *Google in the Classroom: Chromebooks and G Suite Apps* — https://nfb.org/google-classroom-chromebooks-and-g-suite-apps
