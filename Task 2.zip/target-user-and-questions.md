# Target User & Research Questions

## Target user

**Primary:** Asha, 19 — first internship/coursework submitter, Android phone, intermittent mobile data. Needs plain instructions and visible progress at every step, because she completes assignments in short bursts between other commitments and cannot afford to lose work to a dropped connection.

**Secondary (both actively designed for, not deprioritized):**
- **Ravi, 22** — uses a screen magnifier and is keyboard-only on a laptop. Needs scalable text and predictable focus order.
- **Meera, 20** — works on a shared family device with limited uninterrupted time. Needs saved progress and safe session controls (so a sibling picking up the device can't lose or see her work).

Asha is treated as primary because the core task — "understand assigned work, find material, submit proof, recover from feedback" — is most time-and-connectivity sensitive for her; solving for her constraints (clarity, low bandwidth tolerance, resumability) also improves the experience for Ravi and Meera, and the audit separately verifies that Ravi's and Meera's specific needs (focus order, session safety) are not broken by those same fixes.

## Five interview / survey questions

1. **Goal-setting:** "The last time you had an assignment due, what was the very first thing you did after opening the app — and how did you know that was the right first step?"
2. **Friction/hesitation:** "Was there a moment where you paused, went back, or weren't sure what to click next? What were you looking at right before that happened?"
3. **Evidence of state:** "How did you know your work had actually been submitted, versus just saved or still uploading?"
4. **Access-specific:** "If you use a screen reader, magnifier, or keyboard-only navigation (or a shared/older device), where in this flow did the app work against you rather than with you?"
5. **Recovery:** "After your work was graded or returned with a comment, how did you figure out exactly what to change, and how confident were you that you'd fixed it correctly?"

These map directly to the design brief's research template (Goal → Observation → Evidence → Severity → Design response) and are written to surface both usability friction (Q1–Q3) and accessibility-specific barriers (Q4), plus the "recover from reviewer feedback" step named in the brief (Q5).

## Method note

Live participant recruitment wasn't feasible inside the task window, so per the passing checklist's second option, a documented heuristic review was conducted instead (see `heuristic-review.md`) — each persona's Goal/Observation/Evidence/Severity/Design-response is documented exactly as the template specifies, and findings are cross-checked against independently published accessibility reviews of this product rather than left as unverified opinion.
