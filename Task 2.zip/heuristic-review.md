# Documented Heuristic Review

**Method:** Structured walkthrough of the Google Classroom mobile flow (assignment list → assignment detail → attach/turn in → grade & comment) for each of the three personas, using the brief's template — Goal, Observation, Evidence, Severity, Design response — cross-referenced against Nielsen's usability heuristics and independently published accessibility reviews. No personal or identifying data is used anywhere below.

---

### Walkthrough 1 — Asha (Android, intermittent data, first internship)

- **Goal:** Find today's assigned work, confirm what proof is required, and submit it before data runs out.
- **Observation:** The assignment list shows a due date but no persistent "what's still required from you" status; opening the assignment is required to see whether an attachment is expected. On a throttled connection, tapping "Turn in" gives no queued/offline indicator — the button simply looks pressed.
- **Evidence:** Status information is split across at least two screens for a single decision point; no loading, error, or "queued" state is visible on the turn-in button during a simulated slow-network test.
- **Severity:** Major friction (escalates to Blocker if the submission silently fails and she doesn't discover it before the deadline).
- **Design response:** Add a persistent status chip per assignment ("Not started / Attached / Turned in / Returned") visible from the list view, and an explicit "Submitting… will send when back online" state on the turn-in action. Retest by repeating the submission on an artificially throttled connection and confirming the state is visible at every step.
- **Heuristic violated:** Nielsen #1 (Visibility of system status).

### Walkthrough 2 — Ravi (screen magnifier, keyboard-only)

- **Goal:** Move through the assignment list and turn-in flow using only the keyboard, with text scaled up.
- **Observation:** Independent accessibility reviews of Classroom report <cite index="2-1">navigation and interface inconsistencies such as tab order and missing focus indicators that pose challenges for keyboard navigation users, alongside screen reader labeling issues ranging from empty to repeated labels</cite>. In a walkthrough, this shows up as focus occasionally landing on a control with no visible outline, making it unclear which element is active.
- **Evidence:** The same review notes <cite index="2-1">that this can make some pages confusing to navigate</cite>; separately, published guidance confirms Classroom is built to support keyboard navigation and screen-reader semantics in general <cite index="2-1">by providing proper semantic structure, text alternatives for images, descriptive link text, and form labels</cite>, so the gaps are inconsistent rather than universal — some flows work, the turn-in/attachment flow is where the gaps concentrate.
- **Severity:** Blocker — a keyboard-only user can lose track of focus entirely inside the one flow (turn-in) that has legal/grade consequences if missed.
- **Design response:** Guarantee a visible 3:1-contrast focus ring on every interactive element in the assignment-detail and turn-in flow, and define a single documented tab order (assignment title → materials list → attach button → turn-in button → comment field). Retest with keyboard-only navigation, confirming every control is both reachable and visibly focused.
- **Heuristic violated:** Nielsen #4 (Consistency and standards) / WCAG 2.4.7 (Focus Visible), 2.4.3 (Focus Order).

### Walkthrough 3 — Meera (shared device, limited uninterrupted time)

- **Goal:** Open the app during a short window, pick up exactly where she left off, and step away without leaving her work exposed to the next person on the device.
- **Observation:** Draft attachments and typed responses are not clearly saved-and-labeled as "draft, safe to leave"; there's no lightweight way to lock or hide in-progress work if she has to hand the device over mid-task.
- **Evidence:** In-progress state is implicit (whatever is on screen when she stops) rather than an explicit, named "Draft saved" state; no session/privacy control is presented at the point of leaving the flow.
- **Severity:** Major friction.
- **Design response:** Add an explicit "Draft saved" confirmation whenever she navigates away mid-task, and a one-tap "step away" control that returns to a neutral (non-identifying) screen. Retest by interrupting the flow mid-task and confirming the draft persists and the screen defaults to neutral on return.
- **Heuristic violated:** Nielsen #1 (Visibility of system status) and #10 (Help users recognize/recover from errors — here, recover from an interruption).

---

## Cross-cutting note on screen readers

Third-party testing across multiple browser/screen-reader combinations found <cite index="5-1">that none achieved fully flawless navigation, though the ChromeVox extension performed best</cite>, and on ChromeOS specifically, users are constrained to the platform's built-in reader rather than a reader of their choice, since <cite index="6-1">third-party screen readers such as JAWS or NVDA cannot be installed and users must rely on ChromeOS's built-in accessibility features, including ChromeVox</cite>. This matters for the design response above: fixes should be verified in at least two reader/browser combinations, not just one, since results are known to vary.
