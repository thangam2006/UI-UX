# User Research & Accessibility Audit — Google Classroom (Mobile)

**Track:** UI/UX · Task 1
**Product studied:** Google Classroom mobile app (Android/iOS) — a real, widely-used student-facing service that lets a student understand assigned work, find required source material, submit proof of work, and recover from reviewer (teacher) feedback.

This repository is the single proof link for the task. It contains the full research trail: target user definition, interview questions, a documented heuristic review, and a WCAG-based accessibility audit, followed by a prioritized problem list and measurable design goals.

## Why Google Classroom

The design brief describes a "mobile-first service that helps a student understand assigned work, find required source material, submit proof, and recover from reviewer feedback." Google Classroom's core loop — assignment → attached materials → "Mark as done"/"Turn in" → grade & comment — is a close, real-world match, it has a large and well-documented student user base, and it has a public record of accessibility feedback (cited throughout) that makes an evidence-based audit possible without needing access credentials.

## Contents

| File | What it covers |
|---|---|
| [`research/target-user-and-questions.md`](research/target-user-and-questions.md) | Target user definition and the 5 interview/survey questions |
| [`research/heuristic-review.md`](research/heuristic-review.md) | Documented heuristic review (persona walkthroughs + Nielsen heuristics, in place of live interviews) |
| [`audit/accessibility-audit.md`](audit/accessibility-audit.md) | Navigation, readability, contrast, forms, and mobile-usability audit with WCAG references |

## Design problem statement

> Students completing assigned work on a shared or low-bandwidth device — including those using screen magnification or keyboard-only navigation — lose time and confidence because Google Classroom's mobile flow does not clearly show *what to do next*, *where things stand*, or *what changed after feedback*. The result is repeated re-reading of instructions, missed low-contrast status cues, and abandoned "turn in" attempts on constrained connections.

## Measurable success criteria

| Metric | Current (observed/estimated from audit) | Target |
|---|---|---|
| Time to identify "what's due next" on the assignment list | Requires opening 2+ screens; no single always-visible status | ≤ 1 screen, visible within 3 seconds |
| Text/background contrast on status chips and disabled states | As low as 1.69:1–1.96:1 (see audit) | ≥ 4.5:1 for text, ≥ 3:1 for UI components (WCAG 2.2 AA) |
| Keyboard/screen-reader focus order through the "Turn in" flow | Inconsistent focus order reported in independent review (cited) | 100% of interactive elements reachable in a logical, documented tab order |
| Successful "Turn in" completion on a simulated slow/intermittent connection | Fails silently or leaves state ambiguous | Visible offline/queued state; 0 silent failures across 5 test runs |
| Recovery clarity after returned work | Feedback and required re-submission steps are separated across screens | Feedback + next action shown on one screen |

## Top problems, prioritized by user impact (optional portfolio upgrade)

| Rank | Problem | Who it hits hardest | Severity |
|---|---|---|---|
| 1 | Low-contrast disabled/status chips (as low as 1.69:1) make "can I act on this yet?" unreadable | Ravi (low vision), Meera (glancing on a shared device) | Blocker |
| 2 | Inconsistent focus order and some unlabeled controls in the turn-in flow | Ravi (keyboard/screen reader) | Blocker |
| 3 | No visible offline/queued state when submitting on weak mobile data | Asha (intermittent data) | Major friction |
| 4 | Feedback and the corrective action are on separate screens after a returned assignment | All three personas | Major friction |
| 5 | Small tap targets and dense text on narrow screens in the assignment-detail view | Asha, Meera (one-handed, interrupted use) | Minor friction |

Full evidence, quotes/measurements, and design responses for each item are in the linked research and audit files.
